/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes.animais;

/**
 *
 * @author 1129512
 */
public class AnimalEstimacao {
    protected final int id; //atributo da classe - final pois nao pode ser alterado
    protected String nome;
    protected double peso;
    protected String especie;
    
    public AnimalEstimacao(int id, String nome, double peso){
        this.id = id;
        this.nome = nome;
        this.peso = peso;
        this.especie = "Nao Definida";
    }
        public int getId(){
        return id;
    }
 public double getPeso() {
        return peso;
    }

    public String getNome() {
        return nome;
    }   
    public void setNome(String nome){
        this.nome = nome;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
    
    public void getEspecie(){
        
    }
    
    public String produzSom(){
        return "";
    }
    
       public void exibe(){
        System.out.println("Id: " + id);
        System.out.println("Nome: " + nome);
        System.out.println("Peso: " + peso);
        System.out.println("Especie: " + especie);
       }

}
