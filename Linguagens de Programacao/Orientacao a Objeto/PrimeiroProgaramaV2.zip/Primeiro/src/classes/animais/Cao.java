/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes.animais;

/**
 *
 * @author 1129512
 */
public class Cao extends AnimalEstimacao{
    public static final String NOME_CIENTIFICO = "Canis lupus familiaris"; 
    private String raca;
    private double metrosAndados;
    
    public Cao(int id, String nome, String raca, double peso){
        super(id, nome, peso);
        this.raca = raca;
        this.metrosAndados = 0;
        this.especie = "Cachorro";
    }
    
    public Cao(int id, String nome, double peso){
        super(id, nome, peso);
        this.raca = "Nao definida";
        this.especie = "Cachorro";
    }
    

    public String getRaca() {
        return raca;
    }

    public double getMetrosAndados() {
        return metrosAndados;
    }
 
    public void setRaca(String raca) {
        this.raca = raca;
    }

    public void andar(double metros){
        metrosAndados += metros;
    }
    
       public void exibeCao(){

       }

       
    @Override
       public String produzSom(){
           return "Latindo...";
       }

    @Override
       public void exibe(){
        super.exibe();
        System.out.println("Raca: " + raca);
        System.out.println("Metros percorridos: " + metrosAndados); 
       }

}
