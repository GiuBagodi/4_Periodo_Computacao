/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package primeiro;

import classes.Pessoa;
import classes.animais.Ave;
import classes.animais.Cao;
import classes.animais.Gato;

/**
 *
 * @author 1129512
 */
public class Primeiro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cao c1 = new Cao(1, "Apocalipse", "Pinscher", 2.5);
        Cao c2 = new Cao(2, "Meg", "Dachshund", 6.0);
        Gato g1 = new Gato(3, "Tofu", "Persa", 3.5);
        Ave a1 = new Ave(4, "Louro", "Papagaio", true, 0.5);
        
        
        System.out.println("O animal esta " + c1.produzSom());
        System.out.println("O animal esta " + g1.produzSom());
        System.out.println("O animal esta " + a1.produzSom());
        
        
        Pessoa p1 = new Pessoa("Gandalf");
        p1.adota(a1);
        p1.adota(g1);
        p1.adota(c2);
        
        p1.exibe();
      
            
        }
        
    }

 