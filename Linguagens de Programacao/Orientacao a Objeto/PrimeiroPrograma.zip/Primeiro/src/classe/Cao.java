/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classe;

/**
 *
 * @author 1129512
 */
public class Cao {
    public static final String NOME_CIENTIFICO = "Canis lupus familiaris"; //
    private final int id; //atributo da classe - final pois nao pode ser alterado
    private String nome;
    private String raca;
    private double peso;
    private double metrosAndados;
    
    public Cao(int id, String nome, String raca, double peso){
        this.id = id; //id parametro recebe id atributo
        this.nome = nome;
        this.raca = raca;
        this.peso = peso;
        this.metrosAndados = 0;
    }
    
    public Cao(int id, String nome, double peso) {
        this.id = id;
        this.nome = nome;
        this.raca = "Nao definida";
        this.peso = peso;
    }
    
    public int getId(){
        return id;
    }

    public String getRaca() {
        return raca;
    }

    public double getPeso() {
        return peso;
    }

    public String getNome() {
        return nome;
    }

    public double getMetrosAndados() {
        return metrosAndados;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public void andar(double metros){
        metrosAndados += metros;
    }
    
       public void exibeCao(){
        System.out.println("Id: " + id);
        System.out.println("Nome: " + nome);
        System.out.println("Raca: " + raca);
        System.out.println("Peso: " + peso);
        System.out.println("Metros percorridos: " + metrosAndados); 
       }


}
