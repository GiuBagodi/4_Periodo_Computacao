/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package primeiro;

import classe.Cao;

/**
 *
 * @author 1129512
 */
public class Primeiro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cao c1 = new Cao(1, "Apocalipse", "Pinscher", 2.5);
        Cao c2 = new Cao(2, "Panqueca", "Dachshund", 7.0);
        Cao c3 = new Cao(2, "Chimbinha", 20.5);
        
        c1.exibeCao();
        c2.exibeCao();
        c3.exibeCao();
        
        
        System.out.println("O cachorro de id " + c1.getId() + 
                " tem o nome de " + c1.getNome());
        c1.setNome("Biscoito");
        System.out.println("O cachorro de id " + c1.getId() + 
                " tem o novo nome de " + c1.getNome());
       
        System.out.println("O nome cientifico de cao eh "+ Cao.NOME_CIENTIFICO);
    }
}
 