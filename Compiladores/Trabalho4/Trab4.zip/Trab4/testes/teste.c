void main(){
int a;
int b,c;

}
