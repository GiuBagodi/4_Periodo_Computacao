void teste(int a; char b){
    int a, b, c, d, e;
    float b, c;
    char c;

    if (10){
        a=20;
    }
    if (a > b){
        a=20;
        b=30;
        c = a+b;
    }
    else{
        if(a >= c){
            a = c + 10;
        }
        if (a <= b && a > c){
            a = a++;

        }
    }
}
int main(int a){
    int a, b, c, d, e;
    float b, c;
    char c;


    if (10){
        a=20;
        do{
            a=a+b;
        } while(a>20);
    }
    if (10){
        a=20;
        b=30;
        c = a+b;
    }
}
