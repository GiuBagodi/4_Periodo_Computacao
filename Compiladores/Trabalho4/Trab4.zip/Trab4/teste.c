void main(){
int a,b,c;
a=10;
}
