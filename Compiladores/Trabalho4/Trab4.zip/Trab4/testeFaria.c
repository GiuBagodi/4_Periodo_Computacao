int funcao1() 
{
	int a,b,c;
	int d;
	
	a = b + c;
}

char funcao2() {
	int a;
	char b,e;
	int c;
	
	a = 10;
	b = 20;
}
 
void funcao3() {
	a = 30;
}

void main() {
	if ((a > b) && (b > c)) 
	  a = 20;
	
	if (1) {
	  a = 20;
	  while(3) {
	  	if (a) 
	  	  if(b)
	  	    a = 10;
	  }
	  b = 20;
	  c = d + e;
	}
	else {
	  a = b + c;
	}
	
	while(1) {
		a = 10;
	}
	
	do {
	 a = 10;
	} while (10 > a	);
}
